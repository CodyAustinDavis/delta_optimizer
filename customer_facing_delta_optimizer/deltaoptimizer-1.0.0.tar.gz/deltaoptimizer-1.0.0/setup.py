from setuptools import setup

setup(
    name='deltaoptimizer',
    version='1.0.0',
    description='Delta Optimizer Prototype',
    author='Cody Austin Davis @Databricks, Inc.',
    author_email='cody.davis@databricks.com',
    install_requires=[
        'pyspark',
        'sqlparse',
        'sql_metadata'
    ]
)