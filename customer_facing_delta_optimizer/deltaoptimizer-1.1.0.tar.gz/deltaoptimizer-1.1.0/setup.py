from setuptools import setup

setup(
    name='deltaoptimizer',
    version='1.1.0',
    description='Delta Optimizer Prototype - UC Enabled',
    author='Cody Austin Davis @Databricks, Inc.',
    author_email='cody.davis@databricks.com',
    install_requires=[
        'sqlparse',
        'sql_metadata'
    ]
)